console.log('runtime script loaded');

// Function to get localStorage data and send it back to the extension
function getOutlierUserData() {
  try {
    const userData = localStorage.getItem('lscache-internal/logged_in_user');
    // Send data back to the extension
    window.postMessage(
      {
        type: 'OUTLIER_ASSISTANT_DATA',
        data: userData,
        source: 'outlier-content-script',
      },
      '*',
    );
    return userData;
  } catch (error) {
    console.error('Error accessing localStorage:', error);
    window.postMessage(
      {
        type: 'OUTLIER_ASSISTANT_ERROR',
        error: error instanceof Error ? error.message : String(error),
        source: 'outlier-content-script',
      },
      '*',
    );
    return null;
  }
}

// Listen for messages from the extension
window.addEventListener('message', event => {
  // Only accept messages from the same window
  if (event.source !== window) return;

  if (event.data.type === 'GET_OUTLIER_USER_DATA' && event.data.source === 'outlier-extension') {
    getOutlierUserData();
  }
});

// Notify that the script is ready
window.postMessage(
  {
    type: 'OUTLIER_CONTENT_READY',
    source: 'outlier-content-script',
  },
  '*',
);
